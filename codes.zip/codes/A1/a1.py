import unittest

'''class MyTest(unittest.TestCase):
	def setUp(self):
		self.binary_2=search([1,2,3,4,5,10])
	def test_0(self):
		self.assertEqual(self.binary_2.binsearch(2,0,3),1)
	def test_1(self):
		self.assertEqual(self.binary_2.binsearch_nonrecursive(2,0,3),1)
'''
class Mytest(unittest.TestCase):
    def setUp(self):
	    self.obj1=search([10,20,40,50])
    def test0(self):
        self.assertEqual(self.obj1.binsearch(20,0,3),1)
    def test1(self):
        self.assertEqual(self.obj1.binsearch_nonrecursive(20,0,3),1)


class search:
    a=[]
    def __init__(self,arr):
        self.a=arr

    def binsearch(self,num,l,r):
        mid=(l+r)/2
        if(l>r):
            return -1
        elif(self.a[mid]==num):
            return mid
        elif(self.a[mid]>num):
            r=mid-1
        else:
            l=mid+1
        return self.binsearch(num,l,r)  

    def binsearch_nonrecursive(self,num,l,r):
        while(r>=l):
            mid=(l+r)/2
            if(self.a[mid]==num):
                 return mid
            elif(self.a[mid]>num):
                r=mid-1
            else:
                l=mid+1
        return -1

def main():
    filename=raw_input("Enter filename:")
    arr=[]
    obj=open(filename,'r')
    for data in obj:
        arr.append(int(data))
    arr.sort()
    print arr
    obj=search(arr) 
    #while(True):  
    ch=raw_input("enter your choice:\n 1.binary search with recursion. \n 2.binary search without recursion \n 3.exit \n")
    no=input("Enter no to be searched:")
    if ch=='1':          
    	val=obj.binsearch(no,0,len(arr)-1) 
    if ch=='2':
        val=obj.binsearch_nonrecursive(no,0,len(arr)-1) 
        
    if val==-1:
        print "Not found"
    else:
        print "Found at position ",val
        

main()
unittest.main()
