def cipher(text,val=None):
	ctext=""
	if val is not None:
		for symbol in text:
			if symbol.isalpha():
				num=ord(symbol)
				num+=val

				if(symbol.isupper()):
					if(num>ord('Z')):
						num-=26
					elif(num<ord('A')):
						num+=26

				elif(symbol.islower()):
					if(num>ord('z')):
						num-=26
					elif(num<ord('a')):
						num+=26
				ctext+=chr(num)
			else:
				ctext+=symbol

	else:
		arr="abcdefghijklmnopqrstuvwxyz"
		key="qwertyuiopasdfghjklzxcvbnm"

		for symbol in text:
			if symbol.isalpha():
				if symbol.islower():
					i=arr.find(symbol)
					ctext+=key[i]
				else:
					i=arr.find(symbol.lower())
					ctext+=key[i]
			else:
				ctext+=symbol
	return ctext


text=raw_input("Enter plain text\n")
case=input("1. Caesar Cipher \n2. Monoalphabetic Cipher\n")
if case==1:
	key=int(input("Enter key\n"))
	ctext=cipher(text,key)
	print ctext
elif case==2:
	ctext=cipher(text)
	print ctext
else:
	print "Invalid choice..."
